# Fitness-Tracker
Fitness Tracker Application developed by Luke Pratt, Jacob Keeler, and Hayden Riebe for CSCE A470 Capstone class at the University of Alaska Anchorage
